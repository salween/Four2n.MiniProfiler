﻿namespace Orchard.ContentTypes.ViewModels {
    public class RemoveFieldViewModel {
        public string Name { get; set; }
        public EditPartViewModel Part { get; set; }
    }
}
